// data.js
const data = [
    {
        "comment": "This is a sample comment.",
        "created_at": 1658750913,
        "external_id": "123456",
        "feedback_source": "source_1",
        "id": 68641,
        "lang_pair": "en-de",
        "latest_translation": null,
        "license_id": 113,
        "source": "en",
        "source_text": "Example Source Text",
        "status": "new",
        "suggested_translation": "Example Suggested Translation",
        "target": "de",
        "target_text": "Example Target Text",
        "third_party_id": null,
        "translation_rating": 3.0,
        "updated_at": 1658750913,
        "updated_translation_rating": null
    }
];

export default data;
